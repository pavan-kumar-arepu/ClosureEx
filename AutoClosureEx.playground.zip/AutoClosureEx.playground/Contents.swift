import UIKit

var str = "Hello, playground"

//Auto Closures Examples

var customersInLine = ["Chris", "Alex", "Ewa", "Barry", "Daniella", "Kumar", "Tammy", "chommy"]
print(customersInLine.count)

let customerProvider = {
    customersInLine.remove(at: 0)
}
print(customerProvider())
print(customerProvider())
print(customersInLine.count)

print("Now serving \(customerProvider())!")
print(customersInLine.count)


func serve(customer customerProvider:() -> String) {
    print("Now serving \(customerProvider())!")
}

serve { () -> String in
    customersInLine.remove(at: 0)
}

serve(customer : { customersInLine.remove(at: 0)})
print(customersInLine.count)

//serve(customer: customersInLine.remove(at: 0))

var customerProviders: [() -> String] = []

func collectCustomerProviders(_ customerProvider: @autoclosure @escaping () -> String) {
    customerProviders.append(customerProvider)
}

collectCustomerProviders(customersInLine.remove(at: 0))

collectCustomerProviders(customersInLine.remove(at: 0))

print("Collected \(customerProviders.count) closures.")
// Prints "Collected 2 closures."
for customerProvider in customerProviders {
    print("Now serving \(customerProvider())!")
}

let task = URLSession.shared.dataTask(with: URL(string: "http://example.com/cats.jpg")!, completionHandler: { data, response, error in
    // Do something with image data...
})
 
